from app_config import NUM_OF_TOP_STORIES
from correlation_util import calc_correlation
from stories_util import get_top_stories, print_stories, print_comments

top_stories = None
while top_stories is None:
    print('loading HNShell...')
    top_stories = get_top_stories(NUM_OF_TOP_STORIES)

while True:
    print('\nWelcome to HNShell! What can we do for you today?')
    print('[1] show me todays\' 40 top stories')
    print('[2] show me the popularity-posting time correlation')
    try:
        user_choice = int(input())
        while user_choice != 1 and user_choice != 2:
            print('choose between the available options')
            user_choice = int(input())

        if user_choice == 1:
            if top_stories is not None:
                print_stories(top_stories)
                print('Insert an articles rank to watch its comments')
                article_rank = int(input())
                if article_rank < 1:
                    raise IndexError

                print_comments(top_stories[article_rank - 1])
            else:
                print('Something went wrong getting the stories')
                exit()
        else:
            coefficient = None
            while coefficient is None:
                print('we\'re working on it!')
                coefficient = calc_correlation()

            print(f"The correlation coefficient between number of comments to publish "
                  f"proximity to 8pm is:\n {coefficient}")

    except ValueError:
        print('The value entered is not a number\n')
    except IndexError:
        print('Pick a value between 1-40\n')
    except AssertionError:
        print('Please pick a valid option\n')
